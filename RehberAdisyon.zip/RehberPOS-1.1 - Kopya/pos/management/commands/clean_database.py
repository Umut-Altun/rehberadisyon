from django.core.management.base import BaseCommand
from django.db import connection
from django.apps import apps

class Command(BaseCommand):
    help = 'Cleans all data from the database tables'

    def add_arguments(self, parser):
        parser.add_argument(
            '--force',
            action='store_true',
            help='Force the operation without confirmation',
        )

    def handle(self, *args, **options):
        if not options['force']:
            confirm = input('Are you sure you want to delete all data from the database? This action cannot be undone. (yes/no): ')
            if confirm.lower() != 'yes':
                self.stdout.write(self.style.WARNING('Operation cancelled.'))
                return

        # Get all models from the pos app
        pos_app = apps.get_app_config('pos')
        models = pos_app.get_models()

        with connection.cursor() as cursor:
            # Disable foreign key checks temporarily
            cursor.execute('SET CONSTRAINTS ALL DEFERRED;')
            
            # Delete data from all tables
            for model in models:
                try:
                    model.objects.all().delete()
                    self.stdout.write(self.style.SUCCESS(f'Successfully deleted all data from {model._meta.model_name}'))
                except Exception as e:
                    self.stdout.write(self.style.ERROR(f'Error deleting data from {model._meta.model_name}: {str(e)}'))
            
            # Re-enable foreign key checks
            cursor.execute('SET CONSTRAINTS ALL IMMEDIATE;')

        self.stdout.write(self.style.SUCCESS('Database cleaning completed successfully!')) 


# database'i temizlemek için kullanılır.
# python manage.py clean_database

# database'i sıfırlamak için kullanılır.
# python manage.py flush --noinput

# migrate'i sıfırdan başlatmak için kullanılır.
# python manage.py migrate pos zero
